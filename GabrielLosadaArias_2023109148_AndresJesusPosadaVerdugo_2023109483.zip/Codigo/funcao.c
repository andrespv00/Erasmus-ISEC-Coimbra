#define _CRT_SECURE_NO_WARNINGS 1
#include "algoritmo.h"
#include "funcao.h"
#include "utils.h"
#include "stdbool.h"

#define GENERATIONS_TC  100
#define PROBGERAVIZ     1.0

float eval_individual(int sol[], struct info d, int *mat, int *v) {
    int total = 0;
    int i, j;
    int zeros = 0;

    for (i = 0; i < d.numGenes; i++) {
        if (sol[i] == 0) {
            // Check if vertex i has at least one connection
            int has_connection = 0;

            for (j = 0; j < d.numGenes; j++) {
                if (sol[j] == 1 && *(mat + i * d.numGenes + j) != 0) {
                    has_connection = 1;
                    total += *(mat + i * d.numGenes + j); // Sum the weight of the edge instead of counting
                }
            }

            if (!has_connection) {
                zeros++;
            }
        }
    }

    if (zeros > 0) {
        *v = 0;  // Set v to 0 if there are vertices without connections
        return 9999;  // Return a large value for invalid solutions
    } else {
        *v = 1;  // Set v to 1 for valid solutions
        return total;
    }
}


// Evaluate the fitness of the entire population
void evaluate(pchrom pop, struct info d, int *mat) {
    int i;

    for (i = 0; i < d.popsize; i++)
        pop[i].fitness = eval_individual(pop[i].p, d, mat, &pop[i].valido);
}

// Validate function, obtained from chatgpt
int valida(int a[], int *mat, int vert) {
    for (int i = 0; i < vert; i++) {
        if (a[i] == 1) {
            // Verificar si el v�rtice i tiene al menos una conexi�n
            int tiene_conexion = 0;
            for (int j = 0; j < vert; j++) {
                if (a[j] == 1 && *(mat + i * vert + j) > 0 ) {
                    tiene_conexion = 1;
                    break;// Al menos una conexi�n encontrada
                }
            }
            // Si no tiene conexi�n, la soluci�n es inv�lida
            if (!tiene_conexion)
                return 0;
        }
    }
    // Todos los v�rtices seleccionados tienen al menos una conexi�n
    return 1; // Soluci�n v�lida
}

// Calculate the fitness of a solution
int calcula_fit(int a[], int *mat, int vert) {
    int total = 0, val;

    for (int i = 0; i < vert; i++) {
        if (a[i] == 1) {
            for (int j = 0; j < vert; j++) {
                if (a[j] == 1 && *(mat + i * vert + j) != 0) {
                    total = total + *(mat + i * vert + j);  // Suma los pesos de las aristas
                }
            }
        }
    }
    val = valida(a, mat, vert);
    if (val == 1)
        return total / 2;
    else
        return 9999;
}


/*float eval_individual_reparado1(int sol[], struct info d, int *mat, int *v) {
    int total = 0;
    int zeros = 0;
    int i;

    for (i = 0; i < d.numGenes; i++) {
        if (sol[i] == 0) {
            for (int j = 0; j < d.numGenes; j++) {
                if (sol[j] == 0 && *(mat + i * d.numGenes + j) == 1) {
                    total++;
                }
            }
        }
    }
    if (total == 0) {
        for (i = 0; i < d.numGenes; i++) {
            if (sol[i] == 0) {
                zeros++;
            }
        }
        *v = 1;
        return zeros;
    } else {
        // L�gica de reparaci�n
        while (total != 0) {
            do {
                i = random_l_h(0, d.numGenes - 1);
            } while (sol[i] != 0);
            sol[i] = 1;
            total = 0;
            for (int j = 0; j < d.numGenes; j++) {
                if (sol[j] == 0) {
                    for (int k = 0; k < d.numGenes; k++) {
                        if (sol[k] == 0 && *(mat + j * d.numGenes + k) == 1) {
                            total++;
                        }
                    }
                }
            }
        }
        // Recuenta los v�rtices despu�s de la reparaci�n
        zeros = 0;
        for (i = 0; i < d.numGenes; i++) {
            if (sol[i] == 0) {
                zeros++;
            }
        }
        *v = 1;
        return zeros;
    }
}*/
