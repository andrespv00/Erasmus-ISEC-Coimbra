#ifndef EVOLUTIVO_FUNCAO_H
#define EVOLUTIVO_FUNCAO_H
void evaluate(pchrom, struct info, int *mat);

int calcula_fit(int a[], int *mat, int vert);
//void trepa_colinas(pchrom, struct info, int *mat);
int valida(int a[], int *mat, int vert);
#endif //EVOLUTIVO_FUNCAO_H
