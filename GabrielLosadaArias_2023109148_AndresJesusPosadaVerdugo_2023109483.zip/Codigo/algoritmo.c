#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include "algoritmo.h"
#include "utils.h"
#include "funcao.h"

void gera_vizinho(int a[], int b[], int n){
    int i, p1, p2;

    for(i = 0; i < n; i++)
        b[i] = a[i];
    do
        p1 = random_l_h(0, n-1);
    while(b[p1] != 0);
    do
        p2 = random_l_h(0, n-1);
    while(b[p2] != 1);

    b[p1] = 0;
    b[p2] = 1;
}

//Function obtained from the practical sheet 6
void gera_vizinho2(int a[], int b[], int n)
{
    int i, p1, p2, p3, p4;

    for (i = 0; i < n; i++)
        b[i] = a[i];
    do
        p1 = random_l_h(0, n - 1);
    while (b[p1] != 0);
    do
        p2 = random_l_h(0, n - 1);
    while (b[p2] != 1);
    b[p1] = 1;
    b[p2] = 0;
    do
        p3 = random_l_h(0, n - 1);
    while (b[p3] != 0 || p3 == p2);
    do
        p4 = random_l_h(0, n - 1);
    while (b[p4] != 1 || p4 == p1);
    b[p3] = 1;
    b[p4] = 0;
}

int trepa_colinas(int sol[], int *mat, int vert, int num_iter)
{
    int *nova_sol, custo, custo_viz, i;
    nova_sol = malloc(sizeof(int) * vert);
    if (nova_sol == NULL)
    {
        printf("Memory allocation error");
        exit(1);
    }
    custo = calcula_fit(sol, mat, vert);
    for (i = 0; i < num_iter; i++)
    {
        gera_vizinho2(sol, nova_sol, vert);
        //gera_vizinho(sol, nova_sol, vert);
        custo_viz = calcula_fit(nova_sol, mat, vert);
        // Minimization, if you want to accept solutions of equal cost, put <=
        if (custo_viz < custo)//custo_viz <= custo
        {
            substitui(sol, nova_sol, vert);
            custo = custo_viz;
        }
    }
    free(nova_sol);
    return custo;
}

void tournament(pchrom pop, struct info d, pchrom parents)
{
    int i, x1, x2;

    // Performs popsize tournaments
    for (i = 0; i < d.popsize; i++)
    {
        x1 = random_l_h(0, d.popsize - 1);
        do
            x2 = random_l_h(0, d.popsize - 1);
        while (x1 == x2);
        if (pop[x1].fitness < pop[x2].fitness) // Min
            parents[i] = pop[x1];
        else
            parents[i] = pop[x2];
    }
}

void genetic_operators(pchrom parents, struct info d, pchrom offspring)
{
    // Single-point crossover
    //crossover(parents, d, offspring);
    // Two-point crossover
    //recombinacao_dois_pontos_corte(parents, d, offspring);

    // Uniform crossover
    //recombinacao_uniforme(parents, d, offspring);

    // Binary mutation with multiple mutation points
    //mutation(offspring, d);
    // Swap mutation
    //mutacao_por_troca(offspring, d);
}

void crossover(pchrom parents, struct info d, pchrom offspring)
{
    int i, j, point;

    for (i = 0; i < d.popsize; i += 2)
    {
        if (rand_01() < d.pr)
        {
            point = random_l_h(0, d.numGenes - 1);
            for (j = 0; j < point; j++)
            {
                offspring[i].p[j] = parents[i].p[j];
                offspring[i + 1].p[j] = parents[i + 1].p[j];
            }
            for (j = point; j < d.numGenes; j++)
            {
                offspring[i].p[j] = parents[i + 1].p[j];
                offspring[i + 1].p[j] = parents[i].p[j];
            }
        }
        else
        {
            offspring[i] = parents[i];
            offspring[i + 1] = parents[i + 1];
        }
    }
}

void recombinacao_dois_pontos_corte(pchrom parents, struct info d, pchrom offspring)
{
    int i, j, aux, point1, point2;

    for (i=0; i<d.popsize; i+=2)
    {
        if (rand_01() < d.pr)
        {
            point1 = random_l_h(0, d.numGenes-1);
            do
                point2 = random_l_h(0, d.numGenes-1);
            while(point1 == point2);
            if(point1>point2){
                aux = point1;
                point1=point2;
                point2=aux;
            }
            for (j=0; j<point1; j++)
            {
                offspring[i].p[j] = parents[i].p[j];
                offspring[i+1].p[j] = parents[i+1].p[j];
            }
            for (j=point1; j<point2; j++)
            {
                offspring[i].p[j]= parents[i+1].p[j];
                offspring[i+1].p[j] = parents[i].p[j];
            }
            for (j=point2; j<d.numGenes; j++)
            {
                offspring[i].p[j] = parents[i].p[j];
                offspring[i+1].p[j] = parents[i+1].p[j];
            }
        }
        else
        {
            offspring[i] = parents[i];
            offspring[i+1] = parents[i+1];
        }
    }
}

void recombinacao_uniforme(pchrom parents, struct info d, pchrom offspring)
{
    int i, j, mask;

    for (i = 0; i < d.popsize; i += 2)
    {
        if (rand_01() < d.pr)
        {
            for (j = 0; j < d.numGenes; j++)
            {
                mask = flip();
                if (mask == 0)
                {
                    offspring[i].p[j] = parents[i + 1].p[j];
                    offspring[i + 1].p[j] = parents[i].p[j];
                }
                else
                {
                    offspring[i].p[j] = parents[i].p[j];
                    offspring[i + 1].p[j] = parents[i + 1].p[j];
                }
            }
        }
        else
        {
            offspring[i] = parents[i];
            offspring[i + 1] = parents[i + 1];
        }
    }
}

void mutation(pchrom offspring, struct info d)
{
    int i, j;

    for (i = 0; i < d.popsize; i++)
        for (j = 0; j < d.numGenes; j++)
            if (rand_01() < d.pm)
                offspring[i].p[j] = !(offspring[i].p[j]);
}

void mutacao_por_troca(pchrom offspring, struct info d)
{
    int i, pos1, pos2;

    for (i = 0; i < d.popsize; i++)
    {
        do
            pos1 = random_l_h(0, d.numGenes - 1);
        while (offspring[i].p[pos1] != 0);
        do
            pos2 = random_l_h(0, d.numGenes - 1);
        while (offspring[i].p[pos2] != 1);
        if (rand_01() < d.pm)
        {
            offspring[i].p[pos1] = 1;
            offspring[i].p[pos2] = 0;
        }
    }
}
