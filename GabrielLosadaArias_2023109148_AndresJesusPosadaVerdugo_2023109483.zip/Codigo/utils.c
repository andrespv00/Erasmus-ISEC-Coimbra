#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "algoritmo.h"
#include "utils.h"
//#include <string.h>

void init_rand(void){
    srand((unsigned)time(NULL));
}

void imprime_matriz(int *m, int v){
    int i, k=1;
    for (i = 0; i < v*v; i++){
        printf("%d", *(m+i));
        if (i+1 == (k*v)){
            printf("\n");
            k++;
        }
    }
}

int* init_dados(char *nome, int *n, int *kk){
    FILE *f;
    int *p;
    int a=0, i, k, j, v;

    f = fopen(nome, "r");
    if (!f){
        printf("File not found\n");
        exit(1);
    }

    fscanf(f, "k %d ", kk);
    fscanf(f, "p edge %d %d\n", n, &a);
    p = malloc(sizeof(int) * (*n) * (*n));
    if(!p){
        printf("Error on the allocation of memory\n");
        exit(1);
    }

    for(i=0; i<*n; i++)
        for(j=0; j<*n; j++)
            *(p+(*n)*i+j)=0;

    for(i=0; i<a; i++){
        fscanf(f, "e %d %d %d\n", &j, &k, &v);
        *(p+(*n)*(j-1)+k-1)=v; // Almacenamos el peso en lugar de 1
        *(p+(*n)*(k-1)+j-1)=v; // Almacenamos el peso en lugar de 1
    }

    fclose(f);
    return p;
}

int flip(){
    if ((((float)rand()) / RAND_MAX) < 0.5)
        return 0;
    else
        return 1;
}

int random_l_h(int min, int max){
    return min + rand() % (max-min+1);
}

void gera_sol_inicial(int *sol, int k, int v){
    int i, pos1;

    for(i=0; i<v; i++)
        sol[i]=0;
    for(i=0; i<k; i++){
        do
            pos1 = random_l_h(0, v-1);
        while(sol[pos1] != 0);

        sol[pos1] = 1;
    }
}

void substitui(int a[], int b[], int n){
    int i;
    for (i = 0; i < n; i++)
        a[i] = b[i];
}

void escreve_sol(int *sol, int vert){
    int i;
    printf("\nSolution: ");
    for (i = 0; i < vert; i++)
        printf("%2d", sol[i]);
    printf("\n");
}

pchrom init_pop(struct info d){
    int i;
    pchrom indiv;

    indiv = malloc(sizeof(chrom) * d.popsize);
    if (indiv == NULL){
        printf("Error in memory allocation\n");
        exit(1);
    }

    for (i=0; i<d.popsize; i++){
        gera_sol_inicial(indiv[i].p, d.k, d.numGenes);
    }
    return indiv;
}

chrom get_best(pchrom pop, struct info d, chrom best){
    int i;

    for (i=0; i<d.popsize; i++){
        if (best.fitness > pop[i].fitness)
            best=pop[i];
    }
    return best;
}

void write_best(chrom x, struct info d){
    int i;

    printf("\nBest individual: %2d\n", x.fitness);
    for (i=0; i<d.numGenes; i++)
        printf("%d", x.p[i]);
    putchar('\n');
}

float rand_01(void){
    return ((float)rand())/RAND_MAX;
}
