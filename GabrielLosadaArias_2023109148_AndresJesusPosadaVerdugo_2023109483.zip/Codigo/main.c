#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "algoritmo.h"
#include "funcao.h"
#include "utils.h"

#define DEFAULT_RUNS	10
#define DEFAULT_ITERS   50

int main(void)
{
    char    nome_fich[100];
    int     vert, k, kk, runs, cost, best_cost = 0, alg, gen_actual;
    int     *graph, *sol, *best;
    float   mbf = 0.0;
    struct  info EA_param;
    pchrom  pop = NULL, parents = NULL;
    chrom   best_run, best_ever;

    runs = DEFAULT_RUNS;
    printf("File name: ");
    scanf("%s", nome_fich);

    if (runs <= 0)
        return 0;
    init_rand();

    graph = init_dados(nome_fich, &vert, &kk);

    // Display options to the user
    printf("Select an algorithm:\n");
    printf("1. Hill climbing\n");
    printf("2. Evolutionary\n");
    printf("3. Hybrid\n");
    // Read user's choice
    printf("Choice: ");
    scanf("%d", &alg);

    if (alg == 1) {
        sol = malloc(sizeof(int) * vert);
        best = malloc(sizeof(int) * vert);
        if (sol == NULL || best == NULL) {
            printf("Memory allocation error");
            exit(1);
        }
        for (k = 0; k < runs; k++) {
            // Generate initial solution
            gera_sol_inicial(sol, kk, vert);
            escreve_sol(sol, vert);
            cost = trepa_colinas(sol, graph, vert, DEFAULT_ITERS);
            // Write repetition results
            printf("\nRepetition %d:", k + 1);
            escreve_sol(sol, vert);
            // Display the final cost
            printf("Final Cost: %2d\n", cost);
            if (cost != 9999) {
                mbf += cost;
            }
            if (k == 0 || best_cost > cost) {
                best_cost = cost;
                substitui(best, sol, vert);
            }
        }

        printf("\n\nMBF: %f\n", mbf / k);
        printf("\nBest solution found: ");
        escreve_sol(best, vert);
        int x = valida(best, graph, vert);
        printf("Valid = %d\n", x);
        printf("\nFinal Cost: %2d\n", best_cost);
        free(graph);
        free(sol);
        free(best);
    }

    else if (alg == 2) { // Evolutionary Algorithm
        EA_param.numGenerations = 2500;
        EA_param.numGenes = vert;
        EA_param.pm = 0.0;
        EA_param.pr = 0.7;
        EA_param.popsize = 100;
        EA_param.tsize = 2;
        EA_param.k = kk;

        for (k = 0; k < runs; k++) {
            printf("\nRepetition %d", k + 1);
            pop = init_pop(EA_param);
            evaluate(pop, EA_param, graph);
            gen_actual = 1;
            best_run = pop[0];
            best_run = get_best(pop, EA_param, best_run);
            parents = malloc(sizeof(chrom) * EA_param.popsize);
            if (parents == NULL) {
                printf("Memory allocation error\n");
                exit(1);
            }
            // Optimization loop
            while (gen_actual <= EA_param.numGenerations) {
                tournament(pop, EA_param, parents);
                genetic_operators(parents, EA_param, pop);
                // Evaluate the new population (the offspring)
                evaluate(pop, EA_param, graph);
                best_run = get_best(pop, EA_param, best_run);
                gen_actual++;
            }
            // Write results of the finished repetition
            write_best(best_run, EA_param);
            mbf += best_run.fitness;
            // Update the overall best solution
            if (k == 0 || best_run.fitness < best_ever.fitness)
                best_ever = best_run;
            // Free the used memory
            free(parents);
            free(pop);
        }
        // Write overall results
        printf("\n\nMBF: %f\n", mbf / k);
        printf("\nBest solution found");
        write_best(best_ever, EA_param);
    }

    else if (alg == 3) { // Hybrid Algorithm
        EA_param.numGenerations = 2500;
        EA_param.numGenes = vert;
        EA_param.pm = 0.0;
        EA_param.pr = 0.7;
        EA_param.popsize = 100;
        EA_param.tsize = 3;
        EA_param.k = kk;

        for (k = 0; k < runs; k++) {
            printf("\nRepetition %d", k + 1);
            pop = init_pop(EA_param);
            evaluate(pop, EA_param, graph);
            gen_actual = 1;
            best_run = pop[0];
            best_run = get_best(pop, EA_param, best_run);
            parents = malloc(sizeof(chrom) * EA_param.popsize);
            if (parents == NULL) {
                printf("Memory allocation error\n");
                exit(1);
            }
            // Optimization loop
            while (gen_actual <= EA_param.numGenerations) {
                tournament(pop, EA_param, parents);
                genetic_operators(parents, EA_param, pop);
                // Evaluate the new population (the offspring)
                evaluate(pop, EA_param, graph);
                best_run = get_best(pop, EA_param, best_run);
                gen_actual++;
            }
            // Write results of the finished repetition
            write_best(best_run, EA_param);
            mbf += best_run.fitness;
            // Update the overall best solution
            if (k == 0 || best_run.fitness < best_ever.fitness)
                best_ever = best_run;
        }
        // Evaluate the final population using hill climbing
        int i;
        for (i = 0; i < EA_param.popsize; i++)
            pop[i].fitness = trepa_colinas(pop[i].p, graph, vert, 5000);
        best_run = get_best(pop, EA_param, best_run);
        write_best(best_run, EA_param);
        mbf += best_run.fitness;
        if (k == 0 || best_run.fitness < best_ever.fitness)
            best_ever = best_run;
        free(parents);
        free(pop);

        printf("\n\nMBF: %f\n", mbf / k);
        printf("\nBest solution found");
        write_best(best_ever, EA_param);
    }
    else
        printf("Invalid algorithm\n");
    return 0;
}
